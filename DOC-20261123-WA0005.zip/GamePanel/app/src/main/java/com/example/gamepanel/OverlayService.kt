package com.example.gamepanel

import android.app.*
import android.content.*
import android.content.pm.ActivityInfo
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var menu: LinearLayout
    private lateinit var lockView: View
    private lateinit var lockParams: WindowManager.LayoutParams
    private lateinit var tvRam: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvBat: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvClock: TextView
    private lateinit var tvAlert: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val clockFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var gamePkg: String? = null
    private var frames = 0
    private var fps = 0
    private var dnd = false
    private var locked = false
    @Volatile private var ping = -1L
    @Volatile private var running = true

    private val MINT = Color.rgb(61, 245, 192)
    private val YELLOW = Color.rgb(255, 214, 10)
    private val RED = Color.rgb(255, 69, 58)

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            frames++
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            fps = frames; frames = 0
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildLockView()
        buildPanel()
        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.post(tick)
        pingLoop()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        i?.getStringExtra("pkg")?.let { gamePkg = it }
        if (i?.getBooleanExtra("clean", false) == true) cleanRam()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("panel", "Game Panel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Game Panel activo")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun stat() = TextView(this).apply {
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(MINT)
        setPadding(dp(6), 0, dp(6), 0)
    }

    private fun buildLockView() {
        lockView = View(this)
        lockParams = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
        wm.addView(lockView, lockParams)
    }

    private fun buildPanel() {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(Color.argb(215, 8, 20, 18), MINT, 14)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tvRam = stat(); tvFps = stat(); tvTemp = stat()
        tvBat = stat(); tvPing = stat(); tvClock = stat()
        listOf(tvRam, tvFps, tvTemp, tvBat, tvPing, tvClock).forEach { bar.addView(it) }
        root.addView(bar)

        tvAlert = stat().apply { setTextColor(YELLOW); visibility = View.GONE }
        root.addView(tvAlert)

        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6), 0, 0)
        }

        fun item(label: String, a: (TextView) -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(MINT)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = box(Color.argb(200, 20, 40, 36), MINT, 8)
            setOnClickListener { a(this) }
        }

        fun row(vararg items: TextView) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEach {
                addView(it, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
        }

        menu.addView(row(
            item("Limpiar RAM") { cleanRam() },
            item("No molestar: OFF") { toggleDnd(it) },
            item("Bloquear giro: OFF") { toggleLock(it) }
        ))
        menu.addView(row(
            item("Volver al juego") { backToGame() },
            item("Mostrar toques") { openDevOptions() },
            item("Cerrar panel") { stopSelf() }
        ))
        root.addView(menu)

        // Toque corto = abrir/cerrar menú. Arrastrar = mover el panel.
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 15 || Math.abs(e.rawY - ty) > 15) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved)
                    menu.visibility = if (menu.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            true
        }
        wm.addView(root, p)
    }

    private fun tint(v: TextView, bad: Boolean, warn: Boolean) =
        v.setTextColor(if (bad) RED else if (warn) YELLOW else MINT)

    private fun update() {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramPct = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

        tvRam.text = "RAM $ramPct%"
        tvFps.text = "FPS $fps"
        tvTemp.text = "$temp°C"
        tvBat.text = "BAT $lvl%"
        tvPing.text = if (ping < 0) "SIN RED" else "${ping}ms"
        tvClock.text = clockFmt.format(Date())

        tint(tvRam, ramPct > 88, ramPct > 78)
        tint(tvFps, fps < 20, fps < 45)
        tint(tvTemp, temp >= 42, temp >= 38)
        tint(tvPing, ping < 0 || ping > 150, ping > 80)

        tvAlert.text = when {
            temp >= 42 -> "Calor alto: pausa y quita la funda"
            ping > 150 -> "Ping alto: cambia de red"
            ramPct > 88 -> "RAM llena: limpia y reinicia"
            else -> ""
        }
        tvAlert.visibility = if (tvAlert.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun pingLoop() = Thread {
        while (running) {
            ping = try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                (System.nanoTime() - t) / 1_000_000
            } catch (e: Exception) { -1L }
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }.start()

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName && it.packageName != gamePkg }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        Toast.makeText(this, "Procesos en segundo plano cerrados", Toast.LENGTH_SHORT).show()
    }

    private fun toggleDnd(b: TextView) {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
        }
        dnd = !dnd
        nm.setInterruptionFilter(if (dnd) NotificationManager.INTERRUPTION_FILTER_NONE
                                 else NotificationManager.INTERRUPTION_FILTER_ALL)
        b.text = "No molestar: " + if (dnd) "ON" else "OFF"
    }

    private fun toggleLock(b: TextView) {
        locked = !locked
        lockParams.screenOrientation = if (locked)
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        wm.updateViewLayout(lockView, lockParams)
        b.text = "Bloquear giro: " + if (locked) "ON" else "OFF"
    }

    private fun backToGame() {
        val pkgs = listOfNotNull(gamePkg) + listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return }
        }
        Toast.makeText(this, "No encontré el juego", Toast.LENGTH_SHORT).show()
    }

    private fun openDevOptions() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        if (::root.isInitialized) wm.removeView(root)
        if (::lockView.isInitialized) wm.removeView(lockView)
        super.onDestroy()
    }
}

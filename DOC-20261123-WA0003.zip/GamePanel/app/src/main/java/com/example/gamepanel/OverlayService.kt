package com.example.gamepanel

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var tvFps: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvAlert: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var frames = 0
    private var fps = 0
    private var dnd = false
    @Volatile private var ping = -1L
    @Volatile private var running = true

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            frames++
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            fps = frames; frames = 0
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.post(tick)
        pingLoop()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.getBooleanExtra("clean", false) == true) cleanRam()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("panel", "Game Panel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "panel")
            .setContentTitle("Game Panel activo")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun tv() = TextView(this).apply { textSize = 12f; setTextColor(Color.GREEN) }

    private fun buildPanel() {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 10; y = 80 }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(170, 10, 10, 10))
            setPadding(20, 12, 20, 12)
        }
        tvFps = tv(); tvRam = tv(); tvTemp = tv(); tvPing = tv(); tvAlert = tv()
        tvAlert.setTextColor(Color.YELLOW)
        listOf(tvFps, tvRam, tvTemp, tvPing, tvAlert).forEach { root.addView(it) }

        // Botones pequeños, ocultables para no estorbar en partida
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        fun btn(label: String, a: (Button) -> Unit) = Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setOnClickListener { a(this) }
            buttons.addView(this)
        }
        btn("Limpiar RAM") { cleanRam() }
        btn("No molestar: OFF") { toggleDnd(it) }
        btn("Cerrar panel") { stopSelf() }
        root.addView(buttons)

        // Toque corto = mostrar/ocultar botones. Arrastrar = mover panel.
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > 15 || Math.abs(e.rawY - ty) > 15) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved)
                    buttons.visibility = if (buttons.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            true
        }
        wm.addView(root, p)
    }

    private fun color(v: TextView, bad: Boolean, warn: Boolean) =
        v.setTextColor(if (bad) Color.RED else if (warn) Color.YELLOW else Color.GREEN)

    private fun update() {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val usedMb = (mi.totalMem - mi.availMem) / 1048576
        val totalMb = mi.totalMem / 1048576
        val ramPct = (usedMb * 100 / totalMb).toInt()
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

        tvFps.text = "FPS pantalla: $fps"
        tvRam.text = "RAM: $ramPct% ($usedMb/$totalMb MB)"
        tvTemp.text = "Temp: $temp °C  Bat: $lvl%"
        tvPing.text = "Ping: " + if (ping < 0) "sin red" else "$ping ms"
        color(tvFps, fps < 20, fps < 45)
        color(tvRam, ramPct > 88, ramPct > 78)
        color(tvTemp, temp >= 42, temp >= 38)
        color(tvPing, ping < 0 || ping > 150, ping > 80)

        tvAlert.text = when {
            temp >= 42 -> "⚠ Calor: pausa y quita la funda"
            ping > 150 -> "⚠ Ping alto: cambia de red"
            ramPct > 88 -> "⚠ RAM llena: limpia y reinicia"
            else -> ""
        }
        tvAlert.visibility = if (tvAlert.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun pingLoop() = Thread {
        while (running) {
            ping = try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                (System.nanoTime() - t) / 1_000_000
            } catch (e: Exception) { -1L }
            try { Thread.sleep(3000) } catch (e: InterruptedException) { break }
        }
    }.start()

    private fun cleanRam() {
        val am = getSystemService(ActivityManager::class.java)
        packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        Toast.makeText(this, "Procesos en segundo plano cerrados", Toast.LENGTH_SHORT).show()
    }

    private fun toggleDnd(b: Button) {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
        }
        dnd = !dnd
        nm.setInterruptionFilter(if (dnd) NotificationManager.INTERRUPTION_FILTER_NONE
                                 else NotificationManager.INTERRUPTION_FILTER_ALL)
        b.text = "No molestar: " + if (dnd) "ON" else "OFF"
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        if (::root.isInitialized) wm.removeView(root)
        super.onDestroy()
    }
}

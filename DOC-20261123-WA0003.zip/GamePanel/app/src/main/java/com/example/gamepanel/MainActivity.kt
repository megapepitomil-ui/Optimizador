package com.example.gamepanel

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun add(label: String, f: () -> Unit) = col.addView(Button(this).apply {
            text = label; isAllCaps = false; setOnClickListener { f() }
        })
        col.addView(TextView(this).apply {
            text = "Game Panel v2\nOptimiza antes de jugar y vigila calor, RAM y ping."
            textSize = 18f
        })
        add("🎮 MODO JUEGO: Free Fire") { gameMode("com.dts.freefireth") }
        add("🎮 MODO JUEGO: Free Fire MAX") { gameMode("com.dts.freefiremax") }
        add("Solo iniciar panel") { if (hasOverlay()) startPanel(false) }
        add("Detener panel") { stopService(Intent(this, OverlayService::class.java)) }
        add("Opciones de desarrollador (animaciones 0.5x)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        add("Permiso No molestar") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        setContentView(col)
    }

    private fun hasOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")))
        return false
    }

    private fun startPanel(clean: Boolean) {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("clean", clean))
    }

    private fun gameMode(pkg: String) {
        if (!hasOverlay()) return
        startPanel(true) // limpia RAM e inicia el panel
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Ese juego no está instalado", Toast.LENGTH_LONG).show()
    }
}
